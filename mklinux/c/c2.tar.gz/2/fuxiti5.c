#include <stdio.h>
int main(){
	printf("a.\n");
	printf("Baa Baa Black Sheep.");
	printf("Have you any wool?\n");
	printf("b.\n");
	printf("Begone!\nO creature of lard!\n");
	printf("c.\n");
	printf("What?\nNo/nfish?\n");
	printf("d.\n");
	int num = 2;
	printf("%d + %d = %d",num,num,num+num);
	return 0;

}
