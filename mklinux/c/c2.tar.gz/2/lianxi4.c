#include <stdio.h>
void jolly(){
	printf("For he's a jolly!\n");
}
void deny(){
	printf("Which nobody can deny!\n");
}

int main(){
	jolly();
        jolly();
        jolly();
	deny();
	return 0;
}
