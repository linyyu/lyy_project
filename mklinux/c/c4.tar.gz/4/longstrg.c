#include <stdio.h>

int main(){

    printf("Here's one way to print a");
    printf("long string.\n");
    printf("Here's another way to print a \
long string.\n");
    printf("Here's the newest way to print a "
           "long string.\n");


    return 0;
}


